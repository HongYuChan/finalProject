package org.used.domain;

import lombok.Data;

@Data
public class UserImageVO {

	private int image_id;
	private int user_id;
	private String url;
}
