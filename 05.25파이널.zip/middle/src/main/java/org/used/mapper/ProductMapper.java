package org.used.mapper;

import org.used.domain.ProductVO;

public interface ProductMapper {
	public ProductVO read(int product_id);
}
