package org.used.mapper;

import java.util.List;

import org.used.domain.WishListVO;

public interface WishListMapper {
	public List<WishListVO> wishlist();
}
