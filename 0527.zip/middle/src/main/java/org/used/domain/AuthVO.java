package org.used.domain;

import lombok.Data;

@Data
public class AuthVO {
	
	private String user_id;
	private String auth;
}
